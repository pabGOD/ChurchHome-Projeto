import { Component } from '@angular/core';

@Component({
  selector: 'app-cultos',
  imports: [],
  templateUrl: './cultos.component.html',
  styleUrl: './cultos.component.css'
})
export class CultosComponent {

}
